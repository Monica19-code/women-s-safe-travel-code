package com.example.empowerher

data class Message(
    val role: String,        // "user" or "assistant"
    val content: String
)

data class RequestBody(
    val model: String = "openai/gpt-3.5-turbo", // ✅ Updated to valid working model
    val messages: List<Message>
)

data class Choice(
    val message: Message
)

data class OpenRouterResponse(
    val choices: List<Choice>
)

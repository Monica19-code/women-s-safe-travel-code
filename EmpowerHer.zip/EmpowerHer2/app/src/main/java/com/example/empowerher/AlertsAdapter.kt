package com.example.empowerher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class AlertsAdapter(private var alerts: MutableList<SafetyAlert>) : RecyclerView.Adapter<AlertsAdapter.AlertViewHolder>() {

    class AlertViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val locationText: TextView = view.findViewById(R.id.alertLocation)
        val messageText: TextView = view.findViewById(R.id.alertMessage)
        val timeText: TextView = view.findViewById(R.id.alertTime)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlertViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alert, parent, false)
        return AlertViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlertViewHolder, position: Int) {
        val alert = alerts[position]
        holder.locationText.text = alert.locationName
        holder.messageText.text = alert.message
        holder.timeText.text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(alert.timestamp))
    }

    override fun getItemCount(): Int = alerts.size

    // ✅ Function to update alerts dynamically
    fun updateAlerts(newAlerts: List<SafetyAlert>) {
        alerts.clear()  // ✅ Clear old alerts
        alerts.addAll(newAlerts)  // ✅ Add new alerts
        notifyDataSetChanged()  // ✅ Notify RecyclerView
    }
}

package com.example.empowerher

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AlertsFragment : Fragment() {
    private lateinit var alertsAdapter: AlertsAdapter
    private val alertsList = mutableListOf<SafetyAlert>()
    private lateinit var sharedPreferences: SharedPreferences
    private val gson = Gson()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_alerts, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView: RecyclerView = view.findViewById(R.id.alertsRecyclerView)
        alertsAdapter = AlertsAdapter(alertsList)
        recyclerView.adapter = alertsAdapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        sharedPreferences = requireActivity().getSharedPreferences("AlertsPrefs", Context.MODE_PRIVATE)
        loadAlertsFromStorage() // ✅ Load alerts from SharedPreferences
    }

    // ✅ Function to update alerts dynamically and save them
    @SuppressLint("NotifyDataSetChanged")
    fun updateAlerts(newAlerts: List<SafetyAlert>) {
        if (!::alertsAdapter.isInitialized) return // 🚨 Prevent crash if fragment isn't ready

        alertsList.clear() // ✅ Clear old alerts
        alertsList.addAll(newAlerts) // ✅ Add new alerts
        alertsAdapter.notifyDataSetChanged() // ✅ Refresh RecyclerView

        saveAlertsToStorage() // ✅ Save updated alerts
    }

    // ✅ Save alerts to SharedPreferences
    private fun saveAlertsToStorage() {
        sharedPreferences.edit().apply {
            val json = gson.toJson(alertsList)
            putString("alerts_list", json)
            apply() // ✅ Apply changes
        }
    }

    // ✅ Load alerts from SharedPreferences
    @SuppressLint("NotifyDataSetChanged")
    private fun loadAlertsFromStorage() {
        val json = sharedPreferences.getString("alerts_list", null)
        if (!json.isNullOrEmpty()) {
            val type = object : TypeToken<MutableList<SafetyAlert>>() {}.type
            val savedAlerts: MutableList<SafetyAlert> = gson.fromJson(json, type)
            alertsList.clear()
            alertsList.addAll(savedAlerts)
            alertsAdapter.notifyDataSetChanged()
        }
    }
}

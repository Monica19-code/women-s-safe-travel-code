package com.example.empowerher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.empowerher.databinding.ItemBotMessageBinding
import com.example.empowerher.databinding.ItemUserMessageBinding
import java.text.SimpleDateFormat
import java.util.*

class ChatAdapter(private val messages: List<ChatMessage>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_USER = 0
        private const val VIEW_TYPE_BOT = 1
    }

    inner class UserViewHolder(private val binding: ItemUserMessageBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(message: ChatMessage) {
            binding.userMessageText.text = message.message
            binding.userTimestamp.text = getCurrentTime()
        }
    }

    inner class BotViewHolder(private val binding: ItemBotMessageBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(message: ChatMessage) {
            binding.botMessageText.text = message.message
            binding.botTimestamp.text = getCurrentTime()
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].isUser) VIEW_TYPE_USER else VIEW_TYPE_BOT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_USER) {
            val binding = ItemUserMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            UserViewHolder(binding)
        } else {
            val binding = ItemBotMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            BotViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val chatMessage = messages[position]

        // 🔥 Apply slide-in animation
        val animation = if (chatMessage.isUser) {
            AnimationUtils.loadAnimation(holder.itemView.context, R.anim.slide_in_right)
        } else {
            AnimationUtils.loadAnimation(holder.itemView.context, R.anim.slide_in_left)
        }
        holder.itemView.startAnimation(animation)

        // Bind message to correct ViewHolder
        when (holder) {
            is UserViewHolder -> holder.bind(chatMessage)
            is BotViewHolder -> holder.bind(chatMessage)
        }
    }

    override fun getItemCount(): Int = messages.size

    private fun getCurrentTime(): String {
        val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
        return sdf.format(Date())
    }
}

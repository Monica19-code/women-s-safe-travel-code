package com.example.empowerher

data class Coordinates(val lat: Double, val lon: Double)

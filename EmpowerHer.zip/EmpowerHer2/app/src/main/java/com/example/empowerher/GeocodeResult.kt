package com.example.empowerher

data class GeocodeResult(
    val lat: String,
    val lon: String,
    val display_name: String
)
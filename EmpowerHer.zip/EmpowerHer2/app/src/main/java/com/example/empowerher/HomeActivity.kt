package com.example.empowerher

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import com.example.empowerher.databinding.ActivityHomeBinding
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import kotlin.math.*
import com.example.empowerher.SafetyAlert


class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private val alertsList = mutableListOf<SafetyAlert>()
    private var unsafeLocations = mutableListOf<LocationData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        requestNotificationPermission()
        loadFragment(HomeFragment(), "HomeFragment")

        // ✅ Bottom navigation click handler
        binding.bottomNavigation.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    loadFragment(HomeFragment(), "HomeFragment")
                    binding.fabAssistant.hide()
                    true
                }
                R.id.nav_map -> {
                    loadFragment(MapFragment(), "MapFragment")
                    binding.fabAssistant.hide()
                    true
                }
                R.id.nav_alerts -> {
                    val existingFragment = supportFragmentManager.findFragmentByTag("AlertsFragment")
                    val alertsFragment = existingFragment as? AlertsFragment ?: AlertsFragment()
                    loadFragment(alertsFragment, "AlertsFragment")
                    binding.fabAssistant.hide()
                    true
                }
                R.id.nav_safety -> {
                    loadFragment(SafetyFragment(), "SafetyFragment")
                    binding.fabAssistant.hide()
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(ProfileFragment(), "ProfileFragment")
                    binding.fabAssistant.show() // ✅ Show FAB in Profile
                    true
                }
                else -> false
            }
        }


        // ✅ FAB click loads Safety Assistant fragment
        binding.fabAssistant.setOnClickListener {
            loadFragment(SafetyAssistantFragment(), "SafetyAssistantFragment")
        }

        getFCMToken()
        listenForUnsafeLocationUpdates()
        startLocationUpdates()
    }

    private fun loadFragment(fragment: Fragment, tag: String) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.frame_container, fragment, tag)
            .commit()

        // Show FAB only on ProfileFragment
        if (tag == "ProfileFragment") {
            binding.fabAssistant.show()
        } else {
            binding.fabAssistant.hide()
        }
    }


    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                101
            )
        }
    }

    private fun getFCMToken() {
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("FCM", "Fetching FCM token failed", task.exception)
                    return@addOnCompleteListener
                }
                val token = task.result
                Log.d("FCM Token", "Token: $token")
            }
    }

    private fun listenForUnsafeLocationUpdates() {
        db.collection("unsafe_locations").document("TamilNadu")
            .addSnapshotListener { document, error ->
                if (error != null) {
                    Log.e("Firestore", "Error fetching updates", error)
                    return@addSnapshotListener
                }
                if (document != null && document.exists()) {
                    unsafeLocations.clear()
                    val districtsMap = document.get("districts") as? Map<*, *>
                    districtsMap?.forEach { (_, locationData) ->
                        if (locationData is Map<*, *>) {
                            val name = locationData["name"] as? String ?: "Unknown"
                            val lat = (locationData["latitude"] as? Number)?.toDouble() ?: 0.0
                            val lng = (locationData["longitude"] as? Number)?.toDouble() ?: 0.0
                            val riskLevel = locationData["risk_level"] as? String ?: "Unknown"
                            val reason = locationData["reason"] as? String ?: "Unknown"
                            unsafeLocations.add(LocationData(name, lat, lng, riskLevel, reason))
                        }
                    }
                    Log.d("Firestore", "🔥 Updated ${unsafeLocations.size} unsafe locations.")
                }
            }
    }

    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 15000)
            .setMinUpdateIntervalMillis(10000)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    Log.d("Live Location", "Lat: ${location.latitude}, Lng: ${location.longitude}")
                    checkSafetyOfLocation(location.latitude, location.longitude)
                }
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, mainLooper)
    }

    private fun checkSafetyOfLocation(latitude: Double, longitude: Double) {
        val newAlerts = mutableListOf<SafetyAlert>()

        for (unsafeLocation in unsafeLocations) {
            val distance = calculateDistance(latitude, longitude, unsafeLocation.latitude, unsafeLocation.longitude)

            val alertMessage = when {
                distance < 1.0 -> {
                    sendSafetyNotification(unsafeLocation, "⚠️ HIGH RISK AREA! You are in ${unsafeLocation.name}. Stay Alert!")
                    "🚨 HIGH RISK! You are in ${unsafeLocation.name}. Stay Alert!"
                }
                distance < 2.0 -> {
                    sendSafetyNotification(unsafeLocation, "⚠️ Caution! You are approaching ${unsafeLocation.name}. Be careful!")
                    "⚠️ WARNING! You are near ${unsafeLocation.name}. Be careful!"
                }
                else -> null
            }

            if (alertMessage != null && !alertsList.any { it.locationName == unsafeLocation.name }) {
                val newAlert = SafetyAlert(unsafeLocation.name, alertMessage, System.currentTimeMillis())
                newAlerts.add(newAlert)
            }
        }

        if (newAlerts.isNotEmpty()) {
            val alertsFragment = supportFragmentManager.findFragmentByTag("AlertsFragment") as? AlertsFragment
            alertsFragment?.updateAlerts(newAlerts)
        }
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadius = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadius * c
    }

    private fun sendSafetyNotification(locationData: LocationData, message: String) {
        val channelId = "safety_alerts_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val soundUri = "android.resource://${packageName}/raw/alert_sound".toUri()

        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("⚠️ Safety Alert!")
            .setContentText(message)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setDefaults(NotificationCompat.DEFAULT_ALL)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            val channel = NotificationChannel(channelId, "Safety Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                enableLights(true)
                setSound(soundUri, audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }

        notificationManager.notify(1001, notificationBuilder.build())
        Log.d("FCM", "Notification sent: $message")
    }
}

// Data classes
data class LocationData(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val riskLevel: String,
    val reason: String
)



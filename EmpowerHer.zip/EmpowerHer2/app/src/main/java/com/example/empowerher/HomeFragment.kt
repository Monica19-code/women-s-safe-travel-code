package com.example.empowerher

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.empowerher.databinding.FragmentHomeBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Fetch username and display in HomeFragment
        fetchUserName()

        // ✅ Handle SOS Button Click
        binding.btnSos.setOnClickListener {
            triggerSOS()
        }
    }

    private fun fetchUserName() {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            db.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val username = document.getString("name") ?: "User"
                        binding.userTextView.text = "Welcome, $username"
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(requireContext(), "Failed to fetch user data", Toast.LENGTH_SHORT).show()
                }
        }
    }

    // ✅ SOS Functionality
    private fun triggerSOS() {
        playAlertSound() // 🚨 Play the sound
        sendEmergencySMS()
        callEmergencyServices()
        sendFCMAlertToContacts()
    }

    // ✅ Play SOS Alert Sound for 10 Seconds in Background
    private fun playAlertSound() {
        mediaPlayer = MediaPlayer.create(requireContext(), R.raw.sos_alert).apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build()
            )
            isLooping = true
            start()
        }

        // Stop sound after 10 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        }, 10_000)
    }

    // 📌 **1. Send Emergency SMS with Location**
    private fun sendEmergencySMS() {
        val emergencyNumber = "100" // Change to a trusted contact's number if needed
        val smsText = "🚨 SOS! I need help! My location: [Live Location Here]"

        val smsIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse("sms:$emergencyNumber")
            putExtra("sms_body", smsText)
        }
        startActivity(smsIntent)
    }

    // 📌 **2. Call Emergency Services**
    private fun callEmergencyServices() {
        val emergencyNumber = "100" // Change this to the trusted contact number if needed
        val callIntent = android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$emergencyNumber"))
        startActivity(callIntent)
    }

    // 📌 **3. Send FCM Alert to Trusted Contacts**
    private fun sendFCMAlertToContacts() {
        val notificationData = mapOf(
            "to" to "/topics/sos_alerts",
            "notification" to mapOf(
                "title" to "🚨 SOS Alert!",
                "body" to "User is in danger! Please check immediately."
            )
        )

        FirebaseMessaging.getInstance().subscribeToTopic("sos_alerts")
        Toast.makeText(requireContext(), "SOS Alert Sent to Trusted Contacts!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

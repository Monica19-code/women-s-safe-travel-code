package com.example.empowerher
import androidx.core.content.ContextCompat

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import com.google.android.gms.location.*
import com.google.firebase.firestore.FirebaseFirestore
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.IOException

@Suppress("DEPRECATION")
class MapFragment : Fragment() {

    private lateinit var mapView: MapView
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var searchView: SearchView
    private lateinit var listView: ListView
    private lateinit var searchResultsAdapter: ArrayAdapter<String>

    private var userMarker: Marker? = null
    private var destinationMarker: Marker? = null
    private var routePolyline: Polyline? = null  // Safe route overlay
    private var firstLocationUpdate = true  // Track first location update

    private val firestore = FirebaseFirestore.getInstance()
    private val searchResults = mutableListOf<Pair<String, GeoPoint>>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_map, container, false)

        // ✅ Initialize Map & UI
        mapView = view.findViewById(R.id.mapView)
        searchView = view.findViewById(R.id.searchView)
        listView = view.findViewById(R.id.listView)

        Configuration.getInstance().userAgentValue = requireContext().packageName
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true) // ✅ Allow zooming, panning, and gestures freely

        // ✅ Initialize Location Provider
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())

        // ✅ Setup Search ListView
        searchResultsAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1)
        listView.adapter = searchResultsAdapter

        // ✅ Fetch Unsafe Locations
        fetchUnsafeLocations()

        // ✅ Request Location Updates
        requestLocationUpdates()

        // ✅ Search Query Listener
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { searchLocation(it) }
                return true
            }
            override fun onQueryTextChange(newText: String?) = false
        })

        // ✅ Handle Search Result Click
        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedLocation = searchResults[position].second
            selectDestination(selectedLocation)
            searchView.clearFocus()
            listView.visibility = View.GONE
        }


        return view
    }

    @SuppressLint("MissingPermission")
    private fun requestLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(requireContext(), android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
            return
        }

        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000)
            .setMinUpdateIntervalMillis(1000)
            .build()

        fusedLocationClient.requestLocationUpdates(locationRequest, object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                if (!isAdded || view == null || !mapView.isAttachedToWindow) {
                    Log.w("MapFragment", "⏳ Skipping location update, map not ready yet!")
                    return
                }
                locationResult.lastLocation?.let { updateLocationOnMap(it) }
            }
        }, null)
    }


    private fun updateLocationOnMap(location: Location) {
        if (!isAdded || view == null || !mapView.isAttachedToWindow) {
            Log.e("MapFragment", "❌ mapView is not fully initialized yet!")
            return  // ✅ Prevents crash if the map is not ready
        }

        val newLocation = GeoPoint(location.latitude, location.longitude)

        if (userMarker == null) {
            userMarker = Marker(mapView).apply {
                position = newLocation
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                title = "You are here"
                mapView.overlays.add(this)
            }
        } else {
            animateMarkerMovement(userMarker!!, userMarker!!.position, newLocation)
        }

        if (firstLocationUpdate) {
            mapView.controller.setZoom(15.0)
            mapView.controller.setCenter(newLocation)
            firstLocationUpdate = false
        }

        mapView.invalidate()
    }

    private fun animateMarkerMovement(marker: Marker, start: GeoPoint, end: GeoPoint) {
        val distance = start.distanceToAsDouble(end)  // ✅ Distance in meters
        val animationDuration = (distance * 50).toLong().coerceAtMost(2000)  // ✅ Max 2s, min depends on distance

        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = animationDuration  // ✅ Adjust animation duration based on distance
            interpolator = LinearInterpolator()
            addUpdateListener { animation ->
                val fraction = animation.animatedFraction
                val lat = start.latitude + fraction * (end.latitude - start.latitude)
                val lon = start.longitude + fraction * (end.longitude - start.longitude)

                marker.position = GeoPoint(lat, lon)
                mapView.invalidate()
            }
        }
        animator.start()
    }




    private fun searchLocation(query: String) {
        val url = "https://nominatim.openstreetmap.org/search?format=json&q=$query"
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("MapFragment", "❌ Location search failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { responseBody ->
                    val placesArray = JSONArray(responseBody)
                    if (placesArray.length() > 0) {
                        val searchResultsList = mutableListOf<String>()
                        searchResults.clear()

                        for (i in 0 until placesArray.length()) {
                            val place = placesArray.getJSONObject(i)
                            val name = place.optString("display_name", "Unknown Location")
                            val lat = place.optDouble("lat")
                            val lon = place.optDouble("lon")
                            val geoPoint = GeoPoint(lat, lon)

                            searchResultsList.add(name)
                            searchResults.add(Pair(name, geoPoint))
                        }

                        activity?.runOnUiThread {
                            searchResultsAdapter.clear()
                            searchResultsAdapter.addAll(searchResultsList)
                            searchResultsAdapter.notifyDataSetChanged()
                            listView.visibility = View.VISIBLE
                        }
                    }
                }
            }
        })
    }
    private fun fetchUnsafeLocations() {
        firestore.collection("unsafe_locations").get()
            .addOnSuccessListener { documents ->
                Log.d("MapFragment", "🔥 Fetching unsafe locations from Firestore...")

                if (documents.isEmpty) {
                    Log.w("MapFragment", "⚠️ No unsafe locations found in Firestore.")
                    return@addOnSuccessListener
                }

                Log.d("MapFragment", "✅ Found ${documents.size()} unsafe locations.")

                for (document in documents) {
                    val districtsMap = document.get("districts") as? Map<*, *>

                    districtsMap?.forEach { (district, locationData) ->
                        if (locationData is Map<*, *>) {
                            val name = locationData["name"] as? String ?: "Unknown"
                            val latitude = (locationData["latitude"] as? Number)?.toDouble()
                            val longitude = (locationData["longitude"] as? Number)?.toDouble()
                            val riskLevel = locationData["risk_level"] as? String ?: "Unknown"
                            val reason = locationData["reason"] as? String ?: "No details"

                            if (latitude != null && longitude != null) {
                                val geoPoint = GeoPoint(latitude, longitude)
                                Log.d("MapFragment", "📍 Adding marker: $name | Lat=$latitude, Lon=$longitude, Risk=$riskLevel")
                                addMarker(geoPoint, riskLevel, "$name - $reason")
                            } else {
                                Log.e("MapFragment", "❌ Invalid location data in district: $district")
                            }
                        }
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.e("MapFragment", "❌ Firestore fetch failed: ${e.message}")
            }
    }

    private fun addMarker(location: GeoPoint, riskLevel: String, description: String) {
        val marker = Marker(mapView).apply {
            position = location
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Risk Level: $riskLevel"
            snippet = description
            icon = when (riskLevel) {
                "High" -> ResourcesCompat.getDrawable(resources, R.drawable.marker_red, requireContext().theme)
                "Medium" -> ResourcesCompat.getDrawable(resources, R.drawable.marker_orange, requireContext().theme)
                "Low" -> ResourcesCompat.getDrawable(resources, R.drawable.marker_yellow, requireContext().theme)
                else -> ResourcesCompat.getDrawable(resources, R.drawable.marker_gray, requireContext().theme)
            }
        }
        mapView.overlays.add(marker)
        mapView.invalidate()
    }

    private fun selectDestination(destination: GeoPoint) {
        destinationMarker?.let { mapView.overlays.remove(it) }

        destinationMarker = Marker(mapView).apply {
            position = destination
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Destination Selected"
        }

        mapView.overlays.add(destinationMarker)
        mapView.controller.animateTo(destination)
        mapView.invalidate()

        // Request a safe route
        userMarker?.position?.let { start -> requestSafeRoute(start, destination) }
    }

    private fun requestSafeRoute(start: GeoPoint, destination: GeoPoint) {
        val routeUrl = "https://router.project-osrm.org/route/v1/driving/${start.longitude},${start.latitude};${destination.longitude},${destination.latitude}?overview=full&geometries=polyline"

        val client = OkHttpClient()
        val request = Request.Builder().url(routeUrl).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("MapFragment", "❌ Route request failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { responseBody ->
                    val routePoints = parseRoute(responseBody)
                    activity?.runOnUiThread { drawRouteOnMap(routePoints) }
                }
            }
        })
    }

    private fun parseRoute(responseBody: String): List<GeoPoint> {
        val routePoints = mutableListOf<GeoPoint>()
        val jsonResponse = JSONObject(responseBody)
        val routes = jsonResponse.getJSONArray("routes")

        if (routes.length() > 0) {
            val route = routes.getJSONObject(0)
            val geometry = route.getString("geometry")
            routePoints.addAll(decodePolyline(geometry))
        }
        return routePoints
    }

    private fun drawRouteOnMap(routePoints: List<GeoPoint>) {
        routePolyline?.let { mapView.overlays.remove(it) }

        routePolyline = Polyline().apply {
            setPoints(routePoints)
            color = ContextCompat.getColor(requireContext(), R.color.safe_route)

            width = 8f
        }

        mapView.overlays.add(routePolyline)
        mapView.invalidate()
    }
    private fun decodePolyline(encoded: String): List<GeoPoint> {
        val poly = mutableListOf<GeoPoint>()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lng = 0

        while (index < len) {
            var shift = 0
            var result = 0

            do {
                val b = encoded[index++].code - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)

            val dlat = if (result and 1 != 0) (result shr 1).inv() else (result shr 1)
            lat += dlat

            shift = 0
            result = 0

            do {
                val b = encoded[index++].code - 63
                result = result or (b and 0x1f shl shift)
                shift += 5
            } while (b >= 0x20)

            val dlng = if (result and 1 != 0) (result shr 1).inv() else (result shr 1)
            lng += dlng

            poly.add(GeoPoint(lat.toDouble() / 1E5, lng.toDouble() / 1E5))
        }

        return poly
    }

}

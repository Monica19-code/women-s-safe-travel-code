package com.example.empowerher

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.firebase.firestore.FirebaseFirestore
import androidx.core.net.toUri

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        remoteMessage.notification?.let {
            Log.d("FCM", "Message Notification Title: ${it.title}")
            Log.d("FCM", "Message Notification Body: ${it.body}")

            // Force notification UI in foreground
            showNotification(it.title ?: "EmpowerHer Alert", it.body ?: "New Alert")
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "New Token: $token")

        // ✅ Update token in Firestore
        val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
        val userId = auth.currentUser?.uid
        if (userId != null) {
            val db = FirebaseFirestore.getInstance()
            db.collection("users").document(userId)
                .update("fcmToken", token)
                .addOnSuccessListener { Log.d("FCM", "Token updated in Firestore") }
                .addOnFailureListener { Log.e("FCM", "Error updating token", it) }
        }
    }

    private fun showNotification(title: String, message: String) {
        val channelId = "empowerher_alerts_v2" // Changed to force a new channel
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(this, HomeActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // ✅ Force Custom Sound
        val soundUri = "android.resource://${packageName}/raw/alert_sound".toUri()

        // ✅ Call Police Action
        val callIntent = Intent(Intent.ACTION_DIAL)
        val callPendingIntent = PendingIntent.getActivity(
            this, 1, callIntent, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        // ✅ Share Location Action
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "I need help! My location: [Live Location Here]")
        }
        val sharePendingIntent = PendingIntent.getActivity(
            this, 2, shareIntent, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        // ✅ Build the Notification
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification) // Ensure this icon exists in res/drawable
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(soundUri) // 🔥 Custom sound
            .setDefaults(NotificationCompat.DEFAULT_ALL) // Enable vibrations & lights
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(R.drawable.ic_call, "Call Police", callPendingIntent)
            .addAction(R.drawable.ic_share, "Share Location", sharePendingIntent)

        // ✅ For Android 8.0+ (Oreo & above)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationChannel = NotificationChannel(
                channelId, "EmpowerHer Alerts", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableLights(true)
                enableVibration(true)
                setSound(soundUri, null) // 🔥 Ensure sound is set
            }

            notificationManager.createNotificationChannel(notificationChannel)
        }

        // ✅ Show the Notification
        notificationManager.notify(1, notificationBuilder.build())
    }

}

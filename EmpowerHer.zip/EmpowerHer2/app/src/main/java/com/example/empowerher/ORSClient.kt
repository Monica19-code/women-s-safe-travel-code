package com.example.empowerher.network

import com.example.empowerher.model.ORSRouteRequest
import com.example.empowerher.model.ORSRouteResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface ORSClient {
    @POST("v2/directions/foot-walking/geojson")
    fun getRoute(
        @Body body: ORSRouteRequest,
        @Header("Authorization") apiKey: String
    ): Call<ORSRouteResponse>
}

package com.example.empowerher.model

data class ORSRouteRequest(
    val coordinates: List<List<Double>>
)

data class ORSRouteResponse(
    val features: List<Feature>
)

data class Feature(
    val geometry: Geometry,
    val properties: Properties
)

data class Geometry(
    val coordinates: List<List<Double>>
)

data class Properties(
    val summary: Summary
)

data class Summary(
    val distance: Double,
    val duration: Double
)

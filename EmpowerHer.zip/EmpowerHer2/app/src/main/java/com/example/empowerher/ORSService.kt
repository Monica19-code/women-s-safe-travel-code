package com.example.empowerher.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ORSService {
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.openrouteservice.org/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val api: ORSClient = retrofit.create(ORSClient::class.java)
}

package com.example.empowerher

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

interface OpenRouterAPI {
    @POST("v1/chat/completions")
    fun chatCompletion(
        @Body body: RequestBody,
        @Header("Authorization") auth: String, // ✅ Pass dynamically for security
        @Header("HTTP-Referer") referer: String = "https://yourapp.com", // ✅ Required
        @Header("X-Title") title: String = "EmpowerHer Safety Assistant"
    ): Call<OpenRouterResponse>
}

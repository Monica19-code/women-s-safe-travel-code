package com.example.empowerher

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.empowerher.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.bumptech.glide.Glide

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        fetchUserData()

        binding.btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
            requireActivity().finish()
        }

        binding.settingsButton.setOnClickListener {
            // Open settings page
        }

        binding.emergencyContacts.setOnClickListener {
            // Open Emergency Contacts page
        }

        binding.trustedNetwork.setOnClickListener {
            // Open Trusted Network page
        }

        binding.notificationPreferences.setOnClickListener {
            // Open Notification Preferences page
        }

        binding.helpFaq.setOnClickListener {
            // Open Help & FAQ page
        }

        binding.emergencyServicesButton.setOnClickListener {
            // Open Emergency Services page
        }
    }

    private fun fetchUserData() {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            db.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val name = document.getString("name") ?: "User"
                        val email = document.getString("email") ?: "user@example.com"
                        val profilePicUrl = document.getString("profilePicUrl")

                        binding.userName.text = name
                        binding.userEmail.text = email

                        if (!profilePicUrl.isNullOrEmpty()) {
                            Glide.with(this).load(profilePicUrl).into(binding.profileImage)
                        }
                    }
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

package com.example.empowerher

import java.io.Serializable

data class SafetyAlert(
    val locationName: String,
    val message: String,
    val timestamp: Long
) : Serializable

package com.example.empowerher

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.empowerher.databinding.FragmentSafetyAssistantBinding
import com.google.mlkit.nl.languageid.LanguageIdentification
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.URLEncoder

class SafetyAssistantFragment : Fragment() {

    private var _binding: FragmentSafetyAssistantBinding? = null
    private val binding get() = _binding!!

    private lateinit var chatAdapter: ChatAdapter
    private val chatMessages = mutableListOf<ChatMessage>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSafetyAssistantBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupChatUI()

        binding.askButton.setOnClickListener {
            val question = binding.questionInput.text.toString().trim()
            if (question.isNotEmpty()) {
                sendUserMessage(question)
                getAIResponse(question)
                binding.questionInput.setText("")
            }
        }
    }

    private fun setupChatUI() {
        chatAdapter = ChatAdapter(chatMessages)
        binding.chatRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = chatAdapter
        }
    }

    private fun sendUserMessage(message: String) {
        addMessage(message, isUser = true)
    }

    private fun addMessage(message: String, isUser: Boolean) {
        chatMessages.add(ChatMessage(message, isUser))
        chatAdapter.notifyItemInserted(chatMessages.lastIndex)
        binding.chatRecyclerView.post {
            binding.chatRecyclerView.scrollToPosition(chatMessages.lastIndex)
        }
    }

    private fun removeTyping() {
        if (chatMessages.isNotEmpty() && chatMessages.last().message == "Typing...") {
            chatMessages.removeAt(chatMessages.lastIndex)
            chatAdapter.notifyItemRemoved(chatMessages.size)
        }
    }

    private fun getAIResponse(userMessage: String) {
        requireActivity().runOnUiThread {
            addMessage("Typing...", isUser = false)
        }

        if (userMessage.contains("from", ignoreCase = true) &&
            userMessage.contains("to", ignoreCase = true)
        ) {
            removeTyping()
            handleSafeRouteRequest(userMessage)
            return
        }

        val languageIdentifier = LanguageIdentification.getClient()
        languageIdentifier.identifyLanguage(userMessage)
            .addOnSuccessListener { languageCode ->
                val langName = when (languageCode) {
                    "ta" -> "Tamil"
                    "hi" -> "Hindi"
                    "en" -> "English"
                    else -> "English"
                }

                val systemPrompt = Message(
                    role = "system",
                    content = """
                        You are a friendly emotional AI assistant for a women’s safety app.
                        Speak like a kind human – be caring, warm, and supportive.
                        Detect and use the same language as the user: $langName.
                        Reply naturally with emotional depth, not robotic text.
                    """.trimIndent()
                )

                val userPrompt = Message("user", userMessage)
                val messages = listOf(systemPrompt, userPrompt)

                val requestBody = RequestBody(
                    model = "openai/gpt-3.5-turbo",
                    messages = messages
                )

                val apiKey = "Bearer ${BuildConfig.OPENROUTER_API_KEY}"

                RetrofitClient.api.chatCompletion(
                    body = requestBody,
                    auth = apiKey
                ).enqueue(object : Callback<OpenRouterResponse> {
                    override fun onResponse(
                        call: Call<OpenRouterResponse>,
                        response: Response<OpenRouterResponse>
                    ) {
                        requireActivity().runOnUiThread {
                            removeTyping()
                            val aiMessage = response.body()?.choices?.firstOrNull()?.message?.content
                                ?: "Sorry, I didn’t understand that."
                            addMessage(aiMessage, isUser = false)
                        }
                    }

                    override fun onFailure(call: Call<OpenRouterResponse>, t: Throwable) {
                        requireActivity().runOnUiThread {
                            removeTyping()
                            addMessage("Error: ${t.message}", isUser = false)
                        }
                    }
                })
            }
            .addOnFailureListener {
                requireActivity().runOnUiThread {
                    removeTyping()
                    addMessage("Sorry, I couldn’t detect your language.", isUser = false)
                }
            }
    }

    private fun handleSafeRouteRequest(message: String) {
        val pattern = Regex("from (.*?) to (.*)", RegexOption.IGNORE_CASE)
        val match = pattern.find(message)

        if (match != null && match.groupValues.size >= 3) {
            val source = match.groupValues[1].trim()
            val destination = match.groupValues[2].trim()

            requireActivity().runOnUiThread {
                addMessage("Got it! Finding the safest route from *$source* to *$destination* 🛡️", isUser = false)
            }

            geocodeLocation(source) { sourceCoords ->
                if (sourceCoords == null) {
                    requireActivity().runOnUiThread {
                        addMessage("❌ I couldn’t find the location for *$source*.", isUser = false)
                    }
                    return@geocodeLocation
                }

                geocodeLocation(destination) { destCoords ->
                    if (destCoords == null) {
                        requireActivity().runOnUiThread {
                            addMessage("❌ I couldn’t find the location for *$destination*.", isUser = false)
                        }
                        return@geocodeLocation
                    }

                    requireActivity().runOnUiThread {
                        addMessage(
                            "✅ Coordinates found:\n\n" +
                                    "📍 *$source* → (${sourceCoords.lat}, ${sourceCoords.lon})\n" +
                                    "📍 *$destination* → (${destCoords.lat}, ${destCoords.lon})",
                            isUser = false
                        )
                    }

                    // TODO: Safe route API call goes here
                }
            }
        } else {
            requireActivity().runOnUiThread {
                addMessage("Please say: *Find a safe route from [place] to [place]*", isUser = false)
            }
        }
    }

    private fun geocodeLocation(
        locationName: String,
        callback: (Coordinates?) -> Unit
    ) {
        val encodedName = URLEncoder.encode(locationName, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?q=$encodedName&format=json&limit=1"

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "EmpowerHerApp")
            .build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: java.io.IOException) {
                requireActivity().runOnUiThread {
                    callback(null)
                }
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val body = response.body?.string()
                if (body != null) {
                    try {
                        val jsonArray = JSONArray(body)
                        if (jsonArray.length() > 0) {
                            val obj = jsonArray.getJSONObject(0)
                            val lat = obj.getString("lat").toDouble()
                            val lon = obj.getString("lon").toDouble()
                            requireActivity().runOnUiThread {
                                callback(Coordinates(lat, lon))
                            }
                            return
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                requireActivity().runOnUiThread {
                    callback(null)
                }
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

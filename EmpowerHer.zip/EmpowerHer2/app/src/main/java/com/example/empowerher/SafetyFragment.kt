package com.example.empowerher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location

import android.net.Uri
import android.os.Bundle


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class SafetyFragment : Fragment() {

    private lateinit var emergencyCallButton: LinearLayout
    private lateinit var safeModeButton: LinearLayout
    private lateinit var shareLocationButton: LinearLayout
    private lateinit var alertContactsButton: LinearLayout
    private lateinit var manageTrustedContactsButton: Button
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_safety, container, false)

        // Initialize buttons
        emergencyCallButton = view.findViewById(R.id.btn_emergency_call)
        safeModeButton = view.findViewById(R.id.btn_safe_mode)
        shareLocationButton = view.findViewById(R.id.btn_share_location)
        alertContactsButton = view.findViewById(R.id.btn_alert_contacts)
        manageTrustedContactsButton = view.findViewById(R.id.btn_manage_trusted_contacts)

        // Initialize location service
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext())

        // Set click listeners
        emergencyCallButton.setOnClickListener { makeEmergencyCall() }
        safeModeButton.setOnClickListener { activateSafeMode() }
        shareLocationButton.setOnClickListener { shareLocation() }
        alertContactsButton.setOnClickListener { alertTrustedContacts() }
        manageTrustedContactsButton.setOnClickListener { manageTrustedContacts() }

        return view
    }




    // 1️⃣ Emergency Call
    private fun makeEmergencyCall() {
        val emergencyNumber = "100" // Update this as needed
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse("tel:$emergencyNumber")
        startActivity(intent)
    }

    // 2️⃣ Safe Mode (Placeholder)
    private fun activateSafeMode() {
        Toast.makeText(requireContext(), "Safe Mode Activated", Toast.LENGTH_SHORT).show()
        // Future: Add real safe mode functionalities (e.g., location tracking, silent mode)
    }

    // 3️⃣ Share Location
    private fun shareLocation() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                val locationUri = "http://maps.google.com/?q=${location.latitude},${location.longitude}"
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "My location: $locationUri")
                }
                startActivity(Intent.createChooser(intent, "Share via"))
            } else {
                Toast.makeText(requireContext(), "Unable to get location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 4️⃣ Alert Trusted Contacts
    private fun alertTrustedContacts() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2)
            return
        }

        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                val emergencyMessage = "I'm in danger! Here's my location: http://maps.google.com/?q=${location.latitude},${location.longitude}"
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, emergencyMessage)
                }
                startActivity(Intent.createChooser(intent, "Alert Contacts via"))
            } else {
                Toast.makeText(requireContext(), "Unable to get location", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 5️⃣ Manage Trusted Contacts
    private fun manageTrustedContacts() {
        val intent = Intent(requireContext(), TrustedContactsActivity::class.java)
        startActivity(intent)
    }
}

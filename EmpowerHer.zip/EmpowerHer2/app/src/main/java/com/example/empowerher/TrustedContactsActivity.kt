package com.example.empowerher

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TrustedContactsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trusted_contacts) // Create this XML layout
    }
}
